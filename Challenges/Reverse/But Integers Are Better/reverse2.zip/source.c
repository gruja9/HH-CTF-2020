#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int flag_ascii[44] = {104,104,99,116,102,95,102,108,97,103,123,51,48,48,53,97,98,48,53,102,51,102,53,101,100,54,99,55,56,100,100,51,99,100,98,54,57,56,99,100,49,57,57,125};
	char buf[50];
	int buf_ascii[50] = {};
	int i,j;

	printf("Enter the flag: ");
	fgets(buf, 49, stdin);
	buf[strlen(buf)-1] = '\0';
	if(strlen(buf) != 44)
	{
		printf("Incorrect!\n");
		exit(0);
	}

	for(i=0; buf[i] != '\0'; i++) buf_ascii[i] = buf[i];
	for(j=0; j<i; j++)
	{
		if(flag_ascii[j] != buf_ascii[j])
		{
			printf("Incorrect!\n");
			exit(0);
		}
	}
	printf("Correct!\n");

	return 0;
}
